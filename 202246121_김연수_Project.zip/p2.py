# 프로젝트 문제 2번

input = ")(()"

def problem2(input):
    # 이 곳에 코드를 작성하세요.
    # 입력 힌트
    
    """
    주어진 괄호 문자열이 올바른 괄호 문자열이 되기 위해 추가해야 하는 최소 괄호 개수를 반환합니다.

    Args:
        input (str): '('와 ')'로만 이루어진 문자열

    Returns:
        int: 올바른 괄호 문자열로 만들기 위해 추가해야 하는 최소 괄호의 개수
    """

    ''' <Line number별 설명>
    Line 30   : '('가 더 필요한 경우 Count하기 위한 변수 open_needed 선언.(닫는 괄호가 많을 때)
    Line 31   : ')'가 더 필요한 경우 Count하기 위한 변수 close_needed 선언.(여는 괄호가 많을 때)
    Line 34~35: 여는 괄호가 하나 생겼으니 닫는 괄호가 더 필요해짐.
    Line 36   : char == ')'
    Line 37~38: 짝이 맞는 여는 괄호와 매칭.
    Line 39~40: 매칭할 '('가 없으니 여는 괄호가 더 필요함.
    Line 42   : 필요한 괄호 개수를 result에 저장.
    Line 43   : 필요한 괄호 개수 반환.
    '''

    open_needed = 0   
    close_needed = 0  
    
    for char in input:
        if char == '(':
            close_needed += 1 
        else:                    
            if close_needed > 0:
                close_needed -= 1  
            else:
                open_needed += 1   

    result = open_needed + close_needed
    return result
 
result = problem2(input)

assert result == 2
print("정답입니다.")
