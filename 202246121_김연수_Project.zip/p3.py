from collections import deque

# 프로젝트 문제 3번
input = [[4, 3, 2, 1],
         [0, 0, 0, 0],
         [0, 0, 9, 0],
         [1, 2, 3, 4]]
N = 4

forest = []

def problem3(input):
    """
    곰이 숲에서 벌집을 먹으며 성장하는 시뮬레이션을 수행합니다.
    곰은 자신의 크기보다 작은 벌집만 먹을 수 있고,
    벌집을 자기 크기만큼 먹으면 곰의 크기가 1 증가합니다.
    곰이 더 이상 먹을 벌집이 없을 때까지 이동하는 데 걸린 시간(이동 횟수)을 반환합니다.

    Args:
        input (list): 2차원 리스트로 표현된 숲의 상태.
                      곰의 위치는 9, 벌집은 1~8, 빈 공간은 0입니다.

    Returns:
        int: 곰이 벌집을 먹으며 이동한 총 시간(거리)
    """
    
    '''<Line Number별 코드 설명>
    Line 68     : 곰의 초기 크기 설정 (2부터 시작)
    Line 69     : 곰이 먹은 벌집의 개수 초기화
    Line 70     : 곰이 이동한 총 시간 초기화
    Line 71     : 곰의 초기 위치를 (0, 0)으로 임시 설정
    Line 73     : 입력받은 숲(2차원 리스트)을 복사하여 forest에 저장
    Line 74     : 숲의 크기를 N에 저장
    Line 76~78  : 숲 전체를 탐색하여 곰의 위치(값이 9인 위치)를 찾음
    Line 79     : 곰의 위치를 (i, j)로 설정
    Line 80     : 곰이 있던 위치를 빈 공간(0)으로 변경
    Line 82~83  : 곰이 이동할 수 있는 네 방향(상, 하, 좌, 우) 정의
    Line 96     : 방문 여부와 거리를 저장할 배열 초기화 (방문하지 않으면 -1)
    Line 97     : BFS 탐색을 위한 큐 생성(덱을 이용하여)
    Line 98~99  : 시작 위치를 큐에 추가하고 방문 처리
    Line 100    : 먹을 수 있는 벌집 후보 리스트
    Line 102    : 큐가 빌 때까지 반복
    Line 103    : 큐에서 현재 위치 꺼내기
    Line 104    : 네 방향(상, 하, 좌, 우) 탐색
    Line 105~106: 다음 위치 계산
    Line 107    : 다음 위치가 숲 범위 내에 있는지 확인
    Line 108    : 방문하지 않았고, 곰의 크기 이하의 값(벌집 또는 빈 공간)인 경우
    Line 109    : 거리 갱신
    Line 110~111: 먹을 수 있는 벌집이면 후보에 추가
    Line 112    : 다음 위치를 큐에 추가
    Line 113    : 먹을 수 있는 벌집이 있으면
    Line 114    : 거리 기준으로 정렬 (가장 가까운 벌집 선택)
    Line 115    : 가장 가까운 벌집 정보 반환 (거리, x, y)
    Line 116~117: 먹을 수 있는 벌집이 없으면 None 반환
    Line 119    : 곰이 더 이상 먹을 벌집이 없을 때까지 반복
    Line 120    : BFS로 가장 가까운 벌집 탐색
    Line 121~122: 먹을 수 있는 벌집이 없으면 반복 종료
    Line 123    : 벌집까지의 거리와 위치 정보 추출
    Line 124    : 이동한 거리를 총 시간에 더함
    Line 125    : 곰의 위치를 벌집 위치로 이동
    Line 126    : 벌집을 먹고 해당 위치를 빈 공간으로 변경
    Line 127    : 먹은 벌집 개수 증가
    Line 128    : 곰이 자기 크기만큼 벌집을 먹었으면
    Line 129    : 곰의 크기 1 증가
    Line 130    : 먹은 벌집 개수 초기화
    Line 132    : 총 이동 시간(거리) 반환
    '''
    bear_size = 2
    honeycomb_count = 0
    time = 0
    bear_x, bear_y = 0, 0

    forest = [row[:] for row in input]
    N = len(forest)

    for i in range(N):
        for j in range(N):
            if forest[i][j] == 9:
                bear_x, bear_y = i, j
                forest[i][j] = 0

    dx = [-1, 1, 0, 0]
    dy = [0, 0, -1, 1]

    def bfs(sx, sy, size):
        """
        BFS를 이용해 곰이 먹을 수 있는 가장 가까운 벌집을 탐색합니다.

        Args:
            sx, sy (int): 탐색 시작 위치
            size (int): 곰의 현재 크기

        Returns:
            tuple: (거리, 벌집 위치 x, 벌집 위치 y) 또는 없으면 None
        """
        visited = [[-1] * N for _ in range(N)]
        queue = deque()
        queue.append((sx, sy))
        visited[sx][sy] = 0
        candidates = []

        while queue:
            x, y = queue.popleft()
            for dir in range(4):
                nx = x + dx[dir]
                ny = y + dy[dir]
                if 0 <= nx < N and 0 <= ny < N:
                    if visited[nx][ny] == -1 and forest[nx][ny] <= size:
                        visited[nx][ny] = visited[x][y] + 1
                        if 1 <= forest[nx][ny] < size:
                            candidates.append((visited[nx][ny], nx, ny))
                        queue.append((nx, ny))
        if candidates:
            candidates.sort()
            return candidates[0]
        else:
            return None

    while True:
        bfs_result = bfs(bear_x, bear_y, bear_size)
        if bfs_result is None:
            break
        dist, nx, ny = bfs_result
        time += dist
        bear_x, bear_y = nx, ny
        forest[nx][ny] = 0
        honeycomb_count += 1
        if honeycomb_count == bear_size:
            bear_size += 1
            honeycomb_count = 0

    return time

# 함수 호출
result = problem3(input)
assert result == 14
print("정답입니다.")

