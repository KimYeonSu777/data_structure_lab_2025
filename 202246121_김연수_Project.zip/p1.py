# 프로젝트 문제 1번
input = [10, 40, 30, 60, 30]

def problem1(input):
    # 이곳에 코드를 작성하세요.
    """
    주어진 정수 리스트에서 평균값과 중앙값을 계산하여 반환합니다.

    Args:
        input (list of int): 정수로 이루어진 리스트

    Returns:
        list: [평균값, 중앙값] 형태의 리스트
    """
    
    ''' <Line number별 설명>
    Line 32   : 평균값을 저장할 변수 선언.
    Line 33   : 중앙값을 저장할 변수 선언.
    Line 34   : 결과를 저장할 리스트 초기화.
    Line 36   : 리스트를 오름차순으로 정렬.
    Line 37   : 리스트의 길이(원소 개수) 저장.
    Line 38   : 원소들의 합계를 저장할 변수 선언.
    Line 40~41: 리스트의 모든 원소를 더함.
    Line 43   : 평균값을 계산.(소수점 이하는 버림)
    Line 45~46: 중앙값 계산.(리스트 항목 수 홀수일 때)
    Line 47~48: 중앙값 계산.(리스트 항목 수 짝수일 때)
    Line 50   : 결과 리스트에 평균값 저장.
    Line 51   : 결과 리스트에 중앙값 저장.
    Line 52   : 결과 반환.
    '''
    
    mean = 0  
    median = 0 
    result = [0, 0] 

    input.sort()
    n = len(input) 
    input_sum = 0  

    for i in range(n):
        input_sum = input_sum + input[i] 

    mean = input_sum // n
    
    if n % 2 == 1: 
        median = input[n // 2]
    else:       
        median = (input[(n // 2) - 1] + input[n // 2]) // 2

    result[0] = mean
    result[1] = median 
    return result  

result = problem1(input)

assert result == [34, 30]
print("정답입니다.")
